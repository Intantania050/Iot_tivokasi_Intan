#include <Arduino.h>

const int trigPin = 5;   // Trig sensor ke GPIO5 ESP32
const int echoPin = 18;  // Echo sensor ke GPIO18 ESP32

#define SOUND_SPEED 0.034  // Kecepatan suara dalam cm/us
#define CM_TO_INCH 0.393701

long duration;
float distanceCm;
float distanceInch;

void setup() {
    Serial.begin(115200);  // Mulai komunikasi serial
    pinMode(trigPin, OUTPUT);
    pinMode(echoPin, INPUT);
}

void loop() {
    // Membersihkan trigPin
    digitalWrite(trigPin, LOW);
    delayMicroseconds(2);
    
    // Kirim pulsa selama 10 mikrodetik
    digitalWrite(trigPin, HIGH);
    delayMicroseconds(10);
    digitalWrite(trigPin, LOW);
    
    // Baca durasi pantulan suara
    duration = pulseIn(echoPin, HIGH);
    
    // Hitung jarak
    distanceCm = (duration * SOUND_SPEED) / 2;
    distanceInch = distanceCm * CM_TO_INCH;
    
    // Cetak hasil ke Serial Monitor
    Serial.print("Jarak (cm): ");
    Serial.println(distanceCm);
    
    delay(1000);  // Tunggu 1 detik sebelum pengukuran berikutnya
}
