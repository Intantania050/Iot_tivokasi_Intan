#include <Arduino.h>  // Wajib untuk PlatformIO + ESP32
int lampu = 5;
int lampu2 = 21; 
int lampu3 = 22;

void setup() {
    Serial.begin(115200);  // Inisialisasi komunikasi Serial
    Serial.println("ESP32 Blinking LED Bergantian");

    // Atur pin sebagai OUTPUT
    pinMode(lampu, OUTPUT);
    pinMode(lampu2, OUTPUT);
    pinMode(lampu3, OUTPUT);
}

void loop() {
    // Lampu 1 nyala
    digitalWrite(lampu, HIGH);
    digitalWrite(lampu2, LOW);
    digitalWrite(lampu3, LOW);
    Serial.println("Lampu 1 ON");
    delay(500);
    
    // Lampu 2 nyala
    digitalWrite(lampu, LOW);
    digitalWrite(lampu2, HIGH);
    digitalWrite(lampu3, LOW);
    Serial.println("Lampu 2 ON");
    delay(500);

    // Lampu 3 nyala
    digitalWrite(lampu, LOW);
    digitalWrite(lampu2, LOW);
    digitalWrite(lampu3, HIGH);
    Serial.println("Lampu 3 ON");
    delay(500);
}