#include <Arduino.h>

// Define pin numbers
const int ButtonPin = 19;  // GPIO19 connected to the pushbutton
const int LedPin = 18;     // GPIO18 connected to the LED
const int RelayPin = 23;   // GPIO23 connected to the relay module

void setup() {
  pinMode(ButtonPin, INPUT_PULLUP);
  pinMode(LedPin, OUTPUT);
  pinMode(RelayPin, OUTPUT);

  digitalWrite(LedPin, LOW);
  digitalWrite(RelayPin, LOW);
}

void loop() {
  int buttonState = digitalRead(ButtonPin);

  if (buttonState == LOW) {
    digitalWrite(LedPin, HIGH);
    digitalWrite(RelayPin, HIGH);
  } else {
    digitalWrite(LedPin, LOW);
    digitalWrite(RelayPin, LOW);
  }
}
